import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { UserDataService, User } from '../services/user-data.service';

@Component({
  selector: 'app-create-account',
  templateUrl: './create-account.page.html',
  styleUrls: ['./create-account.page.scss'],
})
export class CreateAccountPage {
  user: User = {
    username: '',
    password: '',
    lastName: '',
    firstName: '',
    phone: '',
    class: '',
    neighborhood: '',
  };

  constructor(
    private router: Router,
    private userDataService: UserDataService
  ) {}

  onSubmit() {
    this.userDataService.createUser(this.user);
    this.userDataService.setUserData(this.user);
    this.router.navigate(['/tabs/tab2']);
  }
}
