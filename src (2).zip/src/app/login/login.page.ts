import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { UserDataService } from '../services/user-data.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage {
  username: string = '';
  password: string = '';

  constructor(
    private router: Router,
    private userDataService: UserDataService
  ) {}

  onLogin() {
    if (this.userDataService.login(this.username, this.password)) {
      this.router.navigate(['/tabs/tab2']);
    } else {
      alert('Invalid credentials');
    }
  }
}
