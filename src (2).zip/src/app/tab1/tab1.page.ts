import { Component, OnInit } from '@angular/core';
import { UserDataService, User } from '../services/user-data.service';

@Component({
  selector: 'app-tab1',
  templateUrl: './tab1.page.html',
  styleUrls: ['./tab1.page.scss'],
})
export class Tab1Page implements OnInit {
  user: User = {
    username: '',
    password: '',
    // initialisez d'autres propriétés utilisateur si nécessaire
  };

  constructor(private userDataService: UserDataService) {}

  ngOnInit() {}

  onCreateUser() {
    this.userDataService.createUser(this.user);
    // logiquement, vous voudrez probablement rediriger ou afficher un message de succès ici
  }
}
