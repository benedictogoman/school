import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PartageDocsPage } from './partage-docs.page';

const routes: Routes = [
  {
    path: '',
    component: PartageDocsPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class PartageDocsPageRoutingModule {}
