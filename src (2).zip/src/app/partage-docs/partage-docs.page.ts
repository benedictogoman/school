import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-partage-docs',
  templateUrl: './partage-docs.page.html',
  styleUrls: ['./partage-docs.page.scss'],
})
export class PartageDocsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
