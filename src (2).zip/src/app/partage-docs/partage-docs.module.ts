import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { PartageDocsPageRoutingModule } from './partage-docs-routing.module';

import { PartageDocsPage } from './partage-docs.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    PartageDocsPageRoutingModule
  ],
  declarations: [PartageDocsPage]
})
export class PartageDocsPageModule {}
