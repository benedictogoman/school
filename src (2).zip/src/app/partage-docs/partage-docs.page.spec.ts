import { ComponentFixture, TestBed } from '@angular/core/testing';
import { PartageDocsPage } from './partage-docs.page';

describe('PartageDocsPage', () => {
  let component: PartageDocsPage;
  let fixture: ComponentFixture<PartageDocsPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(PartageDocsPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
