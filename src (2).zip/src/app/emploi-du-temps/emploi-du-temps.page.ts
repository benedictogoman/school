import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emploi-du-temps',
  templateUrl: './emploi-du-temps.page.html',
  styleUrls: ['./emploi-du-temps.page.scss'],
})
export class EmploiDuTempsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
