import { ComponentFixture, TestBed } from '@angular/core/testing';
import { EmploiDuTempsPage } from './emploi-du-temps.page';

describe('EmploiDuTempsPage', () => {
  let component: EmploiDuTempsPage;
  let fixture: ComponentFixture<EmploiDuTempsPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(EmploiDuTempsPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
