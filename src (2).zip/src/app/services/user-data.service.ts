import { Injectable } from '@angular/core';

export interface User {
  username: string;
  password: string;
  // autres propriétés utilisateur
}

@Injectable({
  providedIn: 'root',
})
export class UserDataService {
  private users: User[] = [];

  constructor() {}

  createUser(user: User) {
    this.users.push(user);
  }

  // autres méthodes existantes...
}
