import { ComponentFixture, TestBed } from '@angular/core/testing';
import { LesClassesPage } from './les-classes.page';

describe('LesClassesPage', () => {
  let component: LesClassesPage;
  let fixture: ComponentFixture<LesClassesPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(LesClassesPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
