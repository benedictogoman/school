import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LesClassesPage } from './les-classes.page';

const routes: Routes = [
  {
    path: '',
    component: LesClassesPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class LesClassesPageRoutingModule {}
