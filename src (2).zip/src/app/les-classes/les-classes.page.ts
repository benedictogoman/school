import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-les-classes',
  templateUrl: './les-classes.page.html',
  styleUrls: ['./les-classes.page.scss'],
})
export class LesClassesPage implements OnInit {
  constructor() {}

  ngOnInit() {
    console.log('OnInit');
  }
}
