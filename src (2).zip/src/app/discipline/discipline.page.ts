import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-discipline',
  templateUrl: './discipline.page.html',
  styleUrls: ['./discipline.page.scss'],
})
export class DisciplinePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
