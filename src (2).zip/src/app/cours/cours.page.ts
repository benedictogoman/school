import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-cours',
  templateUrl: './cours.page.html',
  styleUrls: ['./cours.page.scss'],
})
export class CoursPage implements OnInit {
  userClass: string;
  courses: string[];

  constructor(private route: ActivatedRoute) {
    this.userClass = '';
    this.courses = [];
  }

  ngOnInit() {
    this.userClass = this.route.snapshot.paramMap.get('class') || 'Inconnue';
    this.loadCourses();
  }

  loadCourses() {
    // Charger les cours en fonction de la classe de l'utilisateur
    if (this.userClass === '6eme') {
      this.courses = ['Mathématiques', 'Français', 'Histoire', 'Géographie'];
    } else if (this.userClass === '5eme') {
      this.courses = ['Mathématiques', 'Français', 'Sciences', 'Anglais'];
    } else if (this.userClass === 'Terminale') {
      this.courses = ['Philosophie', 'Mathématiques', 'Physique', 'Chimie'];
    } else {
      this.courses = ['Cours généraux'];
    }
  }
}
