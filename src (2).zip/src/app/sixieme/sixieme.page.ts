import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sixieme',
  templateUrl: './sixieme.page.html',
  styleUrls: ['./sixieme.page.scss'],
})
export class SixiemePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
