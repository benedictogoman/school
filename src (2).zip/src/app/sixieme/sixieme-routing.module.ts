import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SixiemePage } from './sixieme.page';

const routes: Routes = [
  {
    path: '',
    component: SixiemePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class SixiemePageRoutingModule {}
