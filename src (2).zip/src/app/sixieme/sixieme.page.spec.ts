import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SixiemePage } from './sixieme.page';

describe('SixiemePage', () => {
  let component: SixiemePage;
  let fixture: ComponentFixture<SixiemePage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(SixiemePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
