import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';

@Component({
  selector: 'app-aide',
  templateUrl: './aide.page.html',
  styleUrls: ['./aide.page.scss'],
})
export class AidePage implements OnInit {
  welcomeMessage: string = '';
  nom: string = '';
  prenom: string = '';
  classe: string = '';

  constructor(private route: ActivatedRoute) {}

  ngOnInit() {
    this.nom = this.route.snapshot.queryParams['nom'];
    this.prenom = this.route.snapshot.queryParams['prenom'];
    this.classe = this.route.snapshot.queryParams['classe'];
  }
}
