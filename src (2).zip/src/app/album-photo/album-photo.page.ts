import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-album-photo',
  templateUrl: './album-photo.page.html',
  styleUrls: ['./album-photo.page.scss'],
})
export class AlbumPhotoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
