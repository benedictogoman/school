import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AlbumPhotoPage } from './album-photo.page';

describe('AlbumPhotoPage', () => {
  let component: AlbumPhotoPage;
  let fixture: ComponentFixture<AlbumPhotoPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(AlbumPhotoPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
